module.exports = {
  poweredByHeader: false,
  webpack5: true,
};
